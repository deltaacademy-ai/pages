---
name: conciliador-lumina
description: Concilia uma Nota Fiscal extraída (JSON da Skill nf-extractor-lumina) contra o histórico de pedidos da Lumina, aplicando a política de conciliação carregada no Project. Devolve uma tabela markdown com status semáforo (✅ Conciliado / ⚠️ Exceção / 🔴 Bloqueio) e flags de auditoria não-bloqueantes. Use sempre que o usuário tiver um ou mais JSONs de NF disponíveis na conversa e pedir para conciliar, validar contra pedido, cruzar com histórico, classificar NFs, gerar relatório de conciliação ou verificar divergências.
---

# conciliador-lumina

Skill que faz a conciliação automatizada das NFs da Lumina contra o histórico de pedidos do mês, aplicando a `politica-conciliacao-lumina.md` carregada no Project Contas a Pagar — Lumina.

**Princípio fundamental:** esta Skill **EXECUTA CODE EXECUTION** para todos os cálculos numéricos. Nenhuma comparação de valor, soma ou cálculo de tolerância é feita por aproximação textual do LLM.

---

## PASSO 1 — Receber os JSONs das NFs

A Skill espera receber, na mesma conversa, **um ou mais JSONs estruturados** produzidos pela Skill `nf-extractor-lumina`. Cada JSON tem o schema:

```json
{
  "numero_nf": "string",
  "data_emissao": "YYYY-MM-DD",
  "fornecedor": { "razao_social": "string", "cnpj": "string" },
  "valor_total": number,
  "itens": [{ "descricao": "string", "valor_unitario": number, "quantidade": number }]
}
```

Se o usuário não tiver JSONs disponíveis na conversa, peça gentilmente: *"Para conciliar, primeiro rode a Skill nf-extractor-lumina nas NFs que você quer processar. Anexe as NFs e peça extração — depois eu concilio."*

---

## PASSO 2 — Carregar histórico de pedidos e políticas via code execution

Use code execution Python para:

1. Ler o arquivo `historico-pedidos-lumina.xlsx` (carregado nos arquivos de contexto do Project, aba "Pedidos do Mês")
2. Consultar o `plano-fornecedores-lumina.md` para validar cadastro de fornecedor (CNPJ)
3. Aplicar as regras da `politica-conciliacao-lumina.md`

Código sugerido:

```python
import pandas as pd

# Carregar histórico de pedidos
pedidos = pd.read_excel("historico-pedidos-lumina.xlsx", sheet_name="Pedidos do Mês")
pedidos.columns = ["num_pedido", "fornecedor", "cnpj", "categoria",
                   "data_emissao", "valor_esperado", "prazo_pagamento", "status"]
```

---

## PASSO 3 — Para CADA NF recebida, executar a sequência de validação

A ordem das validações importa — siga exatamente esta sequência via code execution:

### 3.1 — Validar soma interna dos itens (auditoria não-bloqueante)

```python
soma_itens = sum(item["valor_unitario"] * item["quantidade"] for item in nf["itens"])
diff_interno = round(nf["valor_total"] - soma_itens, 2)
flag_auditoria_interna = abs(diff_interno) >= 0.01
```

Se `flag_auditoria_interna == True`, a NF tem **erro interno do fornecedor** (soma dos itens ≠ valor_total impresso). Isso vira **flag de auditoria, NÃO bloqueia conciliação**.

### 3.2 — Validar fornecedor no plano

Verifique se o CNPJ da NF está cadastrado no `plano-fornecedores-lumina.md`.

- Se NÃO estiver → classificação imediata: **⚠️ Fornecedor não cadastrado** (não prossegue para próximas validações)
- Se estiver → siga para 3.3

### 3.3 — Cruzar com pedido do histórico

Encontre no `historico-pedidos-lumina.xlsx` um pedido onde:
- `cnpj` == CNPJ da NF
- `data_emissao` próxima à da NF (até 5 dias úteis de tolerância)
- `status` == "NF Recebida" ou "Aguardando NF"

Se múltiplos pedidos baterem, use o mais próximo em data. Se nenhum bater → **⚠️ Sem pedido prévio**.

### 3.4 — Calcular tolerância de valor (regra 1% via code execution)

```python
diff_pedido = round(abs(nf["valor_total"] - pedido["valor_esperado"]), 2)
pct_diff = round(diff_pedido / pedido["valor_esperado"] * 100, 2)
conciliado = pct_diff <= 1.0
```

### 3.5 — Verificar duplicidade (janela 30 dias)

Procure outra NF com mesmo CNPJ + mesmo número de NF + mesmo valor (tolerância R$ 0,01) na janela. Se encontrar → **🔴 Bloqueio por duplicidade**.

### 3.6 — Escalada urgente

Se `diff_pedido > 5000.00` → **🔴 Escalada urgente** (independente do percentual).

---

## PASSO 4 — Devolver tabela markdown com status semáforo

Output **fixo**: tabela markdown com uma linha por NF. Colunas obrigatórias:

| Coluna | Conteúdo |
|---|---|
| NF | Número da NF |
| Fornecedor | Razão social abreviada (até 30 chars) |
| Categoria | Categoria do plano de fornecedores |
| Valor NF | Valor total impresso, formato R$ X.XXX,XX |
| Valor Pedido | Valor do pedido cruzado, formato R$ X.XXX,XX |
| Diferença | Diferença em R$ e percentual: ex `R$ 47,00 (0,39%)` |
| Status | Emoji + label (ver tabela abaixo) |
| Flag auditoria | "—" se ok, ou descrição curta se houver flag não-bloqueante |

### Tabela de status

| Status | Significado | Bloqueia pagamento? |
|---|---|---|
| ✅ Conciliado | Dentro de todas as tolerâncias | Não |
| ⚠️ Exceção de valor | Diferença vs pedido > 1% | Sim, até revisão manual |
| ⚠️ Exceção de prazo | NF emitida > 5 dias úteis após o pedido | Não, mas registra |
| ⚠️ Sem pedido prévio | NF sem pedido correspondente | Depende do valor (R$ 2.000) |
| ⚠️ Fornecedor não cadastrado | CNPJ não está no plano | Sim |
| 🔴 Bloqueio por duplicidade | Mesma NF já paga em 30 dias | Sim, sempre |
| 🔴 Escalada urgente | Divergência > R$ 5.000 | Sim, sempre |

### Flag de auditoria (coluna separada)

Quando `flag_auditoria_interna == True` (soma dos itens ≠ valor_total impresso), preencha a coluna "Flag auditoria" com:

> "Erro interno do fornecedor: soma dos itens R$ X.XXX,XX, valor impresso R$ X.XXX,XX (diferença R$ XX,XX)"

A flag de auditoria **não impede a conciliação** — registra para revisão posterior. Uma NF pode ser ✅ Conciliada e ter flag de auditoria ao mesmo tempo.

---

## PASSO 5 — Após a tabela, gerar resumo executivo curto

Após a tabela, adicione 2 a 4 linhas de prosa com:

- Quantas NFs foram processadas
- Quantas conciliadas, quantas em exceção, quantas bloqueadas
- Quantas têm flag de auditoria pendente
- Quanto a Lumina pode liberar para pagamento imediato (somando as conciliadas, mesmo as com flag)
- Quanto fica retido aguardando análise (somando exceções e bloqueios)

Exemplo:

> **Resumo da conciliação:** 2 NFs processadas · 2 conciliadas (R$ 34.567,00 liberados) · 0 exceções · 0 bloqueios. **1 flag de auditoria pendente:** erro interno do fornecedor Embalpouch (R$ 47,00 a investigar com o emissor — pagamento pode prosseguir).

---

## Exemplo de output completo

Para as 2 NFs da AP02 (Gellini + Embalpouch), o output esperado seria:

```markdown
| NF | Fornecedor | Categoria | Valor NF | Valor Pedido | Diferença | Status | Flag auditoria |
|---|---|---|---|---|---|---|---|
| 001234 | Gellini Indústria de Insumos | Matéria-Prima | R$ 22.500,00 | R$ 22.500,00 | R$ 0,00 (0,00%) | ✅ Conciliado | — |
| 005678 | Embalpouch Indústria de Embalagens | Embalagem | R$ 12.067,00 | R$ 12.020,00 | R$ 47,00 (0,39%) | ✅ Conciliado | Erro interno do fornecedor: soma dos itens R$ 12.020,00, valor impresso R$ 12.067,00 (diferença R$ 47,00) |

**Resumo da conciliação:** 2 NFs processadas · 2 conciliadas (R$ 34.567,00 liberados para pagamento) · 0 exceções · 0 bloqueios. **1 flag de auditoria pendente:** erro interno do fornecedor Embalpouch (R$ 47,00 a investigar — pagamento pode prosseguir).
```

---

## Princípios da Skill

- **Code execution para TUDO numérico.** Nunca faça comparação por aproximação textual. O Claude soma errado decimal.
- **Conciliação ≠ ausência de divergência.** Uma NF pode ser conciliada (passa na tolerância) e ainda ter flag de auditoria (erro interno do fornecedor).
- **Bloqueio é última opção.** Só bloqueia quando há risco real (duplicidade, fornecedor não cadastrado, escalada urgente). Erros pequenos viram flag, não bloqueio — para não travar o caixa por R$ 47.
- **Output sempre em tabela + resumo.** Para a próxima Skill (`painel-divergencias-lumina` da AP04) consumir de forma previsível.
