---
name: painel-divergencias-lumina
description: Gera um painel HTML autocontido com a identidade visual Lumina a partir da tabela de conciliação (output da Skill conciliador-lumina). O painel é um artefato HTML inline com 3 seções — resumo executivo, lista de NFs e flags pendentes — pronto para a controller abrir no navegador. Use sempre que o usuário tiver acabado de rodar a Skill conciliador-lumina na conversa e pedir para gerar o painel, montar o relatório executivo, fechar o material da semana ou produzir a peça visual final.
---

# painel-divergencias-lumina

Skill que transforma a tabela markdown de conciliação (output da Skill `conciliador-lumina`) em um **painel HTML autocontido** com a identidade visual Lumina, pronto para apresentação à controller.

**Princípio fundamental:** o painel é a **peça apresentável final** do pipeline. Tudo que veio antes (extração JSON, tabela markdown) é insumo intermediário. Aqui o resultado vira algo que a controller abre no navegador e usa sem precisar de explicação adicional.

---

## PASSO 1 — Receber a tabela de conciliação

A Skill espera que a conversa **já tenha a tabela markdown gerada pela Skill `conciliador-lumina`** disponível no contexto. Não é necessário recolar a tabela — a Skill consulta o histórico recente da conversa.

Se nenhuma tabela de conciliação estiver visível, peça gentilmente: *"Para gerar o painel, primeiro rode a Skill conciliador-lumina nas NFs que você quer apresentar. Depois eu transformo a tabela em painel HTML."*

---

## PASSO 2 — Consultar identidade visual

Antes de gerar HTML, **consulte o arquivo `identidade-visual-lumina.md`** carregado nos arquivos do Project. Você precisará da paleta de cores, tipografia e princípios de design para que o painel reflita fielmente a marca.

Valores que você vai usar (já estão no arquivo, mas estão aqui para referência):

- **Paleta:**
  - Branco quente: `#FBF9F5` (fundo principal)
  - Verde-musgo: `#5C7A5A` (cor de marca, títulos)
  - Verde-musgo escuro: `#3D5A3B` (texto sobre verde claro)
  - Coral terroso: `#C97A5A` (acentos, alertas suaves)
  - Coral profundo: `#8C4D34` (texto sobre coral claro)
  - Cinza-taupe: `#8A857D` (texto secundário)
  - Verde-claro pálido: `#D4DDC9` (fundos positivos)
  - Off-white: `#F5F0E8` (variações sutis)
- **Tipografia:**
  - Títulos: `Fraunces` (Google Fonts) — fallback `Georgia, serif`
  - Corpo: `Inter` (Google Fonts) — fallback `system-ui, sans-serif`
  - Mono: `JetBrains Mono` (opcional, para valores numéricos) — fallback `monospace`
- **Princípios:**
  - Muito espaço negativo (padding 24-48px)
  - Border-radius 8px em cards, 12px em hero, 4px em botões
  - Sem sombras pesadas — usar `0 1px 2px rgba(60, 50, 40, 0.04)` no máximo
  - Sem bordas pretas — usar `#E8E4DC` para delimitação sutil
  - Linhas finas (1px máximo)

---

## PASSO 3 — Estruturar o painel em 3 seções

Sempre nesta ordem, dentro de um container `<main>` com max-width 960px centralizado:

### Seção 1 — Hero / Resumo Executivo

Bloco no topo com:

- **Logo Lumina** em SVG inline (símbolo + texto, conforme `identidade-visual-lumina.md`)
- **Título principal** em Fraunces: "Painel de Divergências"
- **Subtítulo** em Inter, cinza-taupe: data de geração + período (ex: "Gerado em 11/06/2026 · NFs processadas na conciliação atual")
- **Grid de 4 cards de totais** (grid 4 colunas em desktop, 2x2 em mobile):
  1. **NFs Processadas** — número total, label em caixa alta pequena
  2. **Conciliadas** — número (em verde-musgo) + valor R$ total liberado
  3. **Exceções / Bloqueios** — número (em coral terroso se >0; verde-musgo se 0)
  4. **Flags de Auditoria Pendentes** — número (em coral se >0; verde-musgo se 0)

Cada card de total: fundo `#FBF9F5`, border-radius 12px, padding 24-32px, número grande em Fraunces ~36px, label embaixo em Inter Medium ~11px caixa alta cor cinza-taupe.

### Seção 2 — Lista de NFs

Card único com fundo `#FBF9F5`, border-radius 12px, padding 32px:

- **Título da seção** em Fraunces ~22px: "Notas Fiscais Processadas"
- **Tabela interna** sem bordas pretas, com cabeçalho em `#F5F0E8`:
  - Colunas: NF · Fornecedor · Categoria · Valor · Status · Flag
  - Linhas alternadas zebra (sem zebra ou com fundo `#FBF9F5` vs `#FFFFFF`)
  - Status renderizado como **badge** colorido:
    - ✅ Conciliado → fundo `#D4DDC9`, texto `#3D5A3B`
    - ⚠️ Exceção → fundo `#FCEBEB`, texto `#A32D2D`
    - 🔴 Bloqueio → fundo `#A32D2D`, texto branco
  - Coluna Flag em itálico cor `#8C4D34` quando há flag, ou "—" cinza-taupe quando não há

### Seção 3 — Flags de Auditoria Pendentes (call-to-action)

Só renderizar essa seção SE houver pelo menos 1 flag pendente. Caso contrário, **omitir** (não mostrar título vazio).

Card com fundo coral suavizado (`#FAEFE9`), borda esquerda 4px coral terroso (`#C97A5A`), border-radius 12px, padding 32px:

- **Título da seção** em Fraunces ~22px cor `#8C4D34`: "Flags Pendentes de Investigação"
- **Lead text** em Inter ~14px cor `#8C4D34`: "As NFs abaixo foram pagas (passaram na conciliação), mas apresentam inconsistências internas que merecem revisão com o fornecedor."
- **Lista de flags** — uma por flag pendente:
  - **NF + Fornecedor** em negrito (Inter Semibold)
  - **Descrição da flag** em Inter regular
  - **Ação sugerida** em Inter Italic ~12px (ex: "Sugestão: pedir NF corrigida ao fornecedor para arquivamento contábil.")

### Rodapé

Pequena linha cinza-taupe ao final:

> Gerado por `painel-divergencias-lumina` · Pipeline IA · Lumina

---

## PASSO 4 — Gerar como ARTEFATO HTML INLINE

Use a capacidade de gerar artefato HTML do Claude. O artefato deve:

- Ser **autocontido**: todo CSS inline em `<style>` no `<head>`, sem dependências externas exceto Google Fonts
- Carregar Fraunces e Inter via Google Fonts no `<head>`:
  ```html
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@400;500;600&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  ```
- Ter `<title>` no formato: "Painel de Divergências · Lumina"
- Usar CSS custom properties para a paleta:
  ```css
  :root {
    --bg: #FBF9F5;
    --primary: #5C7A5A;
    --primary-dark: #3D5A3B;
    --accent: #C97A5A;
    --accent-dark: #8C4D34;
    --muted: #8A857D;
    --soft: #D4DDC9;
    --soft-alt: #F5F0E8;
    --border: #E8E4DC;
    --danger-bg: #FCEBEB;
    --danger-text: #A32D2D;
  }
  ```
- Ter responsividade mínima (media query em 640px para reduzir grid de totais de 4 colunas para 2x2)
- NUNCA usar localStorage, sessionStorage ou APIs do navegador que falham em artefatos
- NUNCA usar `<form>` ou ícones de bibliotecas externas — só SVG inline

---

## PASSO 5 — Após gerar o artefato, escrever 2-3 linhas curtas de entrega

Depois que o artefato renderizar, adicione uma resposta conversacional curta:

> "**Painel pronto.** Você pode visualizá-lo aqui na conversa e baixar como arquivo HTML clicando no menu do artefato. {Resumo numérico de 1 linha — ex: '2 NFs processadas, ambas conciliadas, R$ 34.567,00 liberados, 1 flag de auditoria pendente sobre a NF Embalpouch.'}"

---

## Princípios da Skill

- **O painel é o produto final.** A controller não precisa ver o JSON, nem a tabela markdown — só este HTML.
- **Identidade visual fiel.** Cada cor, cada fonte, cada espaçamento vem do `identidade-visual-lumina.md`. Sem desvio "criativo".
- **Conciso por padrão.** Sem gráficos, sem decoração supérflua, sem rodapé extenso. 1 página, 3 seções, fim.
- **Status visual claro.** Badges coloridos comunicam status em 1 segundo. Sem precisar ler descrição longa.
- **Seção condicional.** Flags pendentes só aparecem se houver algo a investigar. Sem título vazio.
- **Acessível por padrão.** Contraste WCAG AA mínimo, hierarquia tipográfica clara, espaço para respirar.

---

## Exemplo do output esperado (estrutura HTML)

```html
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Painel de Divergências · Lumina</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@400;500;600&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    :root { /* ... paleta ... */ }
    body { background: var(--bg); font-family: 'Inter', system-ui, sans-serif; color: #2A2A2A; margin: 0; }
    main { max-width: 960px; margin: 0 auto; padding: 48px 24px; }
    /* ... estilos das 3 seções ... */
  </style>
</head>
<body>
  <main>
    <!-- Seção 1: Hero / Resumo -->
    <section class="hero">
      <svg><!-- logo Lumina inline --></svg>
      <h1>Painel de Divergências</h1>
      <p class="subtitle">Gerado em 11/06/2026 · NFs da conciliação atual</p>
      <div class="totais-grid">
        <div class="card-total">
          <div class="numero">2</div>
          <div class="label">NFs Processadas</div>
        </div>
        <!-- ... outros 3 cards ... -->
      </div>
    </section>

    <!-- Seção 2: Lista de NFs -->
    <section class="lista-nfs">
      <h2>Notas Fiscais Processadas</h2>
      <table>
        <!-- ... tabela com badges ... -->
      </table>
    </section>

    <!-- Seção 3: Flags pendentes (só se houver) -->
    <section class="flags-pendentes">
      <h2>Flags Pendentes de Investigação</h2>
      <p>As NFs abaixo foram pagas...</p>
      <ul>
        <li>
          <strong>NF 005678 — Embalpouch Indústria de Embalagens</strong>
          <p>Erro interno do fornecedor: soma dos itens R$ 12.020,00, valor impresso R$ 12.067,00 (diferença R$ 47,00).</p>
          <p class="sugestao">Sugestão: pedir NF corrigida ao fornecedor para arquivamento contábil.</p>
        </li>
      </ul>
    </section>

    <footer>Gerado por painel-divergencias-lumina · Pipeline IA · Lumina</footer>
  </main>
</body>
</html>
```

Este é apenas um esqueleto orientativo — adapte os estilos para refletir fielmente a estética minimalismo wellness premium descrita no `identidade-visual-lumina.md`.
