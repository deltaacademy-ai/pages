---
name: nf-extractor-lumina
description: Extrai os campos estruturados de uma Nota Fiscal (NF) da Lumina em formato JSON. Use sempre que o usuário anexar uma NF em PDF ou imagem (NF-e, DANFE, NFS-e) e pedir para extrair, estruturar, ler, processar, parsear ou converter a NF em dados estruturados. Trigger também em frases como "extrai os dados dessa nota", "transforma essa NF em JSON", "lê essa nota fiscal", "estrutura essa NF" ou "processa essa nota".
---

# nf-extractor-lumina

Skill que extrai os campos estruturados de uma Nota Fiscal (NF) da Lumina e devolve um JSON pronto para consumo pela Skill de conciliação (AP03 do Project Contas a Pagar — Lumina).

**Princípio fundamental:** esta Skill **EXTRAI E ESTRUTURA**. Ela NÃO calcula, NÃO valida soma de itens, NÃO compara contra pedido. Cálculos e validações ficam por conta da próxima Skill (conciliação) que usa code execution.

---

## PASSO 1 — Receber a NF

O usuário vai anexar uma NF como:
- PDF (DANFE — Documento Auxiliar da NF-e)
- Imagem (PNG, JPG de NF escaneada)
- XML (NF-e original do SEFAZ)

A Skill aceita qualquer um desses formatos.

Se o usuário NÃO anexou um arquivo, peça gentilmente: *"Anexe a NF que você quer extrair (PDF, imagem ou XML)."*

---

## PASSO 2 — Identificar os campos visualmente

Use a capacidade de visão do Claude (para PDF/imagem) ou leitura direta (para XML) para localizar os seguintes campos na NF:

### Campos obrigatórios

1. **Número da NF** — geralmente no canto superior direito, formato "Nº NNNNNN" ou "Nº 000.NNN"
2. **Data de emissão** — no bloco de datas (geralmente no meio da NF), formato dd/mm/aaaa
3. **Razão Social do fornecedor** (emitente) — no cabeçalho superior esquerdo
4. **CNPJ do fornecedor** — abaixo da razão social, formato XX.XXX.XXX/XXXX-XX
5. **Valor total da NF** — no bloco "CÁLCULO DO IMPOSTO" → campo "VALOR TOTAL DA NF" (geralmente em destaque/negrito)
6. **Itens** — na tabela "DADOS DOS PRODUTOS / SERVIÇOS", uma linha por item

### Campos por item

Para cada linha da tabela de produtos:
- **Descrição** — coluna "DESCRIÇÃO DO PRODUTO/SERVIÇO"
- **Valor unitário** — coluna "VL. UNIT."
- **Quantidade** — coluna "QTDE"

---

## PASSO 3 — Estruturar o output em JSON

Devolva EXATAMENTE este formato, sem markdown ao redor, sem comentários no JSON, sem explicações antes ou depois (apenas o bloco JSON):

```json
{
  "numero_nf": "001234",
  "data_emissao": "2025-10-02",
  "fornecedor": {
    "razao_social": "GELLINI INDÚSTRIA DE INSUMOS ALIMENTÍCIOS LTDA",
    "cnpj": "12.345.678/0001-90"
  },
  "valor_total": 22500.00,
  "itens": [
    {
      "descricao": "GELATINA INDUSTRIAL BOVINA 250 BLOOM",
      "valor_unitario": 1250.00,
      "quantidade": 18
    }
  ]
}
```

### Regras de formatação dos valores numéricos

- **Valores monetários** (`valor_total`, `valor_unitario`): devolva como NUMBER (não string), com ponto como separador decimal — convertendo de "R$ 1.250,00" para `1250.00`.
- **Quantidade**: NUMBER inteiro ou decimal conforme aparece na NF.
- **Datas**: formato ISO 8601 (`YYYY-MM-DD`), convertendo de "02/10/2025" para `"2025-10-02"`.
- **CNPJ**: preserve a formatação com pontos, barra e traço (`XX.XXX.XXX/XXXX-XX`).

### O que NÃO fazer

- ❌ NÃO some os valores unitários para calcular o `valor_total` — extraia o que está IMPRESSO no campo "VALOR TOTAL DA NF" da própria NF.
- ❌ NÃO valide se a soma dos itens bate com o valor total. Essa validação é feita pela Skill de conciliação na AP03 via code execution.
- ❌ NÃO arredonde valores. Preserve as casas decimais como vêm na NF.
- ❌ NÃO adicione campos extras (como "observacoes", "frete", "impostos") — atenha-se ao schema acima.

---

## PASSO 4 — Verificação final antes de entregar

Antes de retornar o JSON, faça um sanity check:

- [ ] CNPJ tem 14 dígitos (com pontos, barra e traço incluídos: 18 caracteres)
- [ ] Data está no formato ISO `YYYY-MM-DD`
- [ ] `valor_total` é um número, não uma string
- [ ] Cada item tem os 3 campos (`descricao`, `valor_unitario`, `quantidade`)
- [ ] O JSON é VÁLIDO (pode ser parseado por `JSON.parse()`)

Se algum campo estiver ausente na NF, use `null` (não invente valores).

---

## Exemplos

### Exemplo de NF com 1 item

```json
{
  "numero_nf": "001234",
  "data_emissao": "2025-10-02",
  "fornecedor": {
    "razao_social": "GELLINI INDÚSTRIA DE INSUMOS ALIMENTÍCIOS LTDA",
    "cnpj": "12.345.678/0001-90"
  },
  "valor_total": 22500.00,
  "itens": [
    {
      "descricao": "GELATINA INDUSTRIAL BOVINA 250 BLOOM",
      "valor_unitario": 1250.00,
      "quantidade": 18
    }
  ]
}
```

### Exemplo de NF com múltiplos itens (note: valor_total é o IMPRESSO, não a soma calculada)

```json
{
  "numero_nf": "005678",
  "data_emissao": "2025-10-06",
  "fornecedor": {
    "razao_social": "EMBALPOUCH INDÚSTRIA DE EMBALAGENS FLEXÍVEIS LTDA",
    "cnpj": "45.678.901/0001-23"
  },
  "valor_total": 12067.00,
  "itens": [
    { "descricao": "POUCH METALIZADO 60G C/ZIP", "valor_unitario": 1.28, "quantidade": 5000 },
    { "descricao": "POUCH METALIZADO 120G C/ZIP", "valor_unitario": 1.84, "quantidade": 2500 },
    { "descricao": "ETIQUETA HOLOGRAFICA SELO", "valor_unitario": 0.85, "quantidade": 1200 }
  ]
}
```

---

## Como esta Skill se integra com o Project

Esta Skill é a **primeira camada** do pipeline de Contas a Pagar — Lumina:

1. **nf-extractor-lumina (esta Skill)** → extrai JSON estruturado da NF
2. **conciliador-lumina (Skill da AP03)** → consume o JSON, faz code execution para validar soma, compara contra o histórico de pedidos
3. **painel-divergencias-lumina (Skill da AP04)** → consome resultado da conciliação e gera HTML executivo

A divisão é proposital — esta Skill é **rápida e barata em tokens** (apenas leitura + estruturação), enquanto a conciliação faz o trabalho pesado de aritmética.
