---
name: extrair-receita-crm-lumina
description: Recebe o export agregado do CRM da Lumina (vendas reais da semana com canal de aquisição first-click e loja de fechamento) e devolve a apuração executiva da receita real por canal — tabelas por canal, matriz canal × loja e isolamento dos canais pagos — com observação preliminar sobre o que o CRM revela. Use sempre que o usuário anexar o CSV do CRM da semana e pedir para extrair, apurar ou agregar a receita real, ou para entender o que o CRM mostra sobre os canais de aquisição.
---

# extrair-receita-crm-lumina

Skill que transforma o export agregado do CRM da Lumina (linhas por canal-loja-dia) na apuração executiva da receita real da semana, organizada por canal de aquisição first-click.

**Filosofia:** receita real é o que entrou no caixa, e o canal de origem é o que trouxe o cliente pela primeira vez. Esta skill faz a leitura "operacional" do CRM — depois, a skill `calcular-roas-real-lumina` cruza com o gasto pixel da skill anterior para apurar ROAS real.

---

## PASSO 0 — Carregar contexto do Project

Antes de qualquer ação, leia o arquivo de contexto do Project Resultados de Mídia — Lumina:

- **`plano-de-midia-lumina.md`** — usado aqui para entender os canais que recebem investimento (Paid Social = Meta, Paid Search = Google) e a meta de % de vendas via canal pago

Confirme com:

> ✅ Plano de mídia Lumina carregado para contexto.

---

## PASSO 1 — Receber e validar o CSV do CRM

O usuário vai anexar 1 arquivo agregado do CRM com as colunas:

- `data_pedido` — data
- `canal_first_click` — canal de origem do cliente (Paid Social, Paid Search, Organic Search, Direct, Email, Organic Social)
- `loja` — onde a venda foi fechada (`ecommerce`, `loja_sp`, `loja_rj`)
- `qtd_pedidos` — quantidade de pedidos agregados nessa combinação canal-loja-dia
- `receita_total_brl` — receita total agregada
- `ticket_medio_brl` — ticket médio dos pedidos

Validações:

- O CSV cobre os 7 dias da semana (segunda a domingo)?
- Os canais aparecem com nomenclatura consistente?
- As lojas usam apenas `ecommerce`, `loja_sp` ou `loja_rj`?

Se algo não bater, peça confirmação antes de prosseguir.

---

## PASSO 2 — Calcular agregações

A partir do CSV agregado, gerar:

- **Total por canal:** somatório de receita e pedidos por canal first-click
- **Total por loja:** somatório de receita e pedidos por loja
- **Matriz canal × loja:** cruzamento (linhas = canais, colunas = lojas)
- **Canais pagos isolados:** apenas Paid Social e Paid Search
- **% de cada canal pago que vai para loja física vs e-commerce**
- **Ticket médio ponderado** por canal e por loja

---

## PASSO 3 — Devolver o output em 4 partes

### PARTE 1 — Receita total por canal (first-click)

Tabela ordenada por receita descendente. Colunas:

| Canal | Pedidos | Receita total (R$) | Ticket médio (R$) | % sobre receita total |

Linha final: **TOTAL**.

### PARTE 2 — Desdobramento por loja (matriz canal × loja)

Matriz com receita em R$:

|  | E-commerce | Loja SP | Loja RJ | Total |
|--|-----------:|--------:|--------:|------:|
| Paid Social | ... | ... | ... | ... |
| Paid Search | ... | ... | ... | ... |
| Organic Search | ... | ... | ... | ... |
| Direct | ... | ... | ... | ... |
| Email | ... | ... | ... | ... |
| Organic Social | ... | ... | ... | ... |
| **Total** | ... | ... | ... | ... |

### PARTE 3 — Canais pagos isolados

Tabela específica para Paid Social e Paid Search:

| Canal pago | Receita total (R$) | Receita e-commerce (R$) | Receita lojas físicas (R$) | % para lojas físicas |

### PARTE 4 — Observação preliminar (2 parágrafos curtos)

- **Parágrafo 1 — O que o CRM mostra:** sintetize o peso real de cada canal na receita da semana. Destaque qual canal lidera e qual a participação dos canais pagos no total.
- **Parágrafo 2 — Lojas físicas vs e-commerce:** aponte como cada canal pago se comporta entre canais de venda — quanto da receita de Paid Social/Search se materializou em loja física, e o que isso significa em termos de leitura.

**Importante:** **NÃO** ainda compare com pixel ou calcule ROAS. Isso é função da skill `calcular-roas-real-lumina`. Aqui, o tom é "olhando só o CRM, o que vemos".

---

## Tom e estilo

- Português brasileiro executivo, direto
- Analista sênior — usa "first-click", "atribuição", "canal de aquisição" sem explicar
- Comentário em prosa curta — máximo 3 frases por parágrafo
- Valores monetários sempre `R$ 1.234,56`
- Percentuais com 1 casa decimal

---

## Não faça

- **Não compare** com pixel ou platform-reported revenue — isso é da próxima skill
- **Não calcule ROAS** — também é da próxima skill
- **Não invente** dados — use apenas o CSV anexado
- **Não recomende ajustes operacionais** — espere o cruzamento da próxima skill

---

## Tratamento de erros

- **Plano de mídia faltando:** prossiga, mas avise que a observação final não vai ter referência de meta
- **CSV sem colunas essenciais:** sinalize qual falta e peça novo upload
- **Receita zerada em algum canal/dia:** sinalize na observação (pode indicar problema de tracking)

---

## Exemplo de comportamento esperado

**Input:**
> "Anexei o CRM da semana 12-18 mai. Extraia a receita por canal."

**Output:**

1. ✅ Plano de mídia Lumina carregado para contexto.
2. PARTE 1 — Receita por canal (ordenada por receita)
3. PARTE 2 — Matriz canal × loja
4. PARTE 3 — Canais pagos isolados
5. PARTE 4 — Observação preliminar de 2 parágrafos
6. Mensagem final: *"Receita real extraída. Próximo passo: rodar a skill `calcular-roas-real-lumina` para cruzar com o gasto pixel e apurar o ROAS real da semana."*
