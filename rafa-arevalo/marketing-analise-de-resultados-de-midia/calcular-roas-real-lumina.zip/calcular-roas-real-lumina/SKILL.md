---
name: calcular-roas-real-lumina
description: Cruza o gasto pixel (output da skill consolidar-midia-lumina) com a receita real do CRM (output da skill extrair-receita-crm-lumina) e calcula o ROAS real vs ROAS reportado pelo pixel, com status semáforo vs metas e comentário executivo completo para o CMO. Use sempre que as duas skills anteriores tiverem rodado na mesma conversa e o usuário pedir para apurar o ROAS real, reconciliar pixel vs CRM, fechar a análise da semana ou gerar o reconciliation report.
---

# calcular-roas-real-lumina

Skill que faz o cruzamento crítico da aula: gasto pixel × receita real do CRM, produzindo o reconciliation report semanal da Lumina — incluindo ROAS real por plataforma, status semáforo vs metas e o comentário executivo final.

**Filosofia:** o pixel reporta o que ele consegue ver (cookies, atribuição própria, janela permissiva). O CRM mostra o que realmente entrou em receita. A diferença entre os dois é o "gap pixel → real" — e nomear esse gap é o entregável mais valioso da semana.

---

## PASSO 0 — Carregar contexto do Project (OBRIGATÓRIO)

Antes de qualquer ação, leia:

- **`plano-de-midia-lumina.md`** — para extrair as metas mensais (ROAS real mínimo, CPA real máximo, receita real total via mídia paga) e converter para metas semanais (divida a meta mensal por 4,3)

Confirme com:

> ✅ Plano de mídia Lumina carregado com metas semanais derivadas.

---

## PASSO 1 — Validar contexto da conversa

Esta skill **depende** das tabelas geradas pelas 2 skills anteriores na mesma conversa:

- Da `consolidar-midia-lumina`: gasto por plataforma + receita pixel reportada
- Da `extrair-receita-crm-lumina`: receita real por canal first-click + matriz canal × loja

Se algum desses outputs não estiver na conversa atual, **pare e peça** ao usuário para rodar as 2 skills anteriores primeiro.

---

## PASSO 2 — Calcular o cruzamento

Mapeamento entre canal pixel e canal first-click:

| Plataforma pixel | Canal first-click correspondente no CRM |
|---|---|
| Meta Ads | Paid Social |
| Google Ads | Paid Search |

Para cada plataforma, calcular:

- **ROAS pixel reportado** = valor pixel / gasto
- **ROAS real CRM** = receita CRM do canal correspondente / gasto da plataforma
- **Gap absoluto (R$)** = valor pixel − receita CRM
- **Gap % (sobre valor pixel)** = gap absoluto / valor pixel
- **CPA real (R$)** = gasto / qtd pedidos do canal pago no CRM

Linha **TOTAL ADS PAGOS** = somas correspondentes.

---

## PASSO 3 — Devolver o output em 4 partes

### PARTE 1 — Tabela Reconciliation (ROAS Reportado vs Real)

| Plataforma | Gasto (R$) | Receita pixel (R$) | ROAS pixel | Receita CRM real (R$) | ROAS real | Gap absoluto (R$) | Gap % | CPA real (R$) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Meta Ads / Paid Social | ... | ... | ...x | ... | ...x | ... | ...% | ... |
| Google Ads / Paid Search | ... | ... | ...x | ... | ...x | ... | ...% | ... |
| **TOTAL** | ... | ... | ...x | ... | ...x | ... | ...% | ... |

### PARTE 2 — Status vs Metas (Semáforo)

Calcular metas semanais a partir do plano de mídia carregado (divida meta mensal por 4,3):

| Métrica | Meta semanal | Realizado | Variação | Status |
|---|---:|---:|---:|---|
| ROAS real total | 2.0x | 2.10x | +5% | ✅ |
| CPA real total | R$ 110 | R$ 95 | -14% | ✅ |
| Receita real via canais pagos | R$ 74.418 | R$ 80.258 | +8% | ✅ |
| ROAS real Meta isolado | 2.0x | 2.24x | +12% | ✅ |
| ROAS real Google isolado | 2.0x | 1.82x | -9% | 🔴 |

**Regras do semáforo:**

- ✅ **META BATIDA EM X%** — verde, com a porcentagem de superação da meta (ex: "META BATIDA EM 5%")
- ⚠️ **DENTRO DA META** — amarelo, quando estiver entre 90% e 100% da meta (ex: "DENTRO DA META — 95%")
- 🔴 **ABAIXO DA META EM X%** — vermelho, quando abaixo de 90% da meta (ex: "ABAIXO DA META EM 9%")

### PARTE 3 — Comentário executivo para o CMO (4 blocos em bullets)

**Cada bloco deve ter o título em negrito como primeiro item, depois 1 a 3 bullets de descrição curta (cada bullet com no máximo 2 frases).**

- **🎯 O número da semana**
  - Bullet 1: ROAS real consolidado vs meta semanal
  - Bullet 2: ROAS pixel reportado e gap em %
  - Bullet 3 (opcional): headline para Slack

- **🔍 Por que o pixel está superestimando**
  - Bullet 1: pixel atribui vendas que viriam orgânico/direto
  - Bullet 2: janela de atribuição do pixel é mais permissiva (post-view, cross-device)
  - Bullet 3: pixel não vê fechamentos de loja física quando o cliente começou no digital

- **💎 Onde está o ouro escondido**
  - Bullet 1: peso das lojas físicas vinda de canais digitais pagos
  - Bullet 2: força real do Direct/Organic (indicador de marca consolidada)
  - Bullet 3 (opcional): outro insight relevante do mix de canais

- **🚀 Recomendação acionável para a próxima semana**
  - Apenas 1 bullet com **uma única recomendação** concreta — qual ajuste de budget ou criativo a Lumina deve fazer na próxima semana com base no que o reconciliation revelou. Nunca múltiplas recomendações.

### PARTE 4 — 3 bullets para Slack

Bullets curtíssimos (no máximo 12 palavras cada) para o CMO copiar e colar no Slack do time:

```
• [Headline com o número-síntese — ex: ROAS real 2.10x, acima do piso de 2.0x]
• [Gap pixel vs real — ex: Pixel reportou 45% a mais do que o CRM apurou]
• [Recomendação — ex: Realocar 15% do budget Google para Meta na próxima semana]
```

---

## Tom e estilo

- Português brasileiro executivo, direto, acionável
- Analista sênior conversando com CMO — **objetividade > completude**
- Bullets curtos, nunca mais de 2 frases por bullet
- Valores monetários sempre `R$ 1.234,56`
- ROAS sempre `0.00x`
- Percentuais sempre com 1 casa decimal e sinal explícito (+5% ou -9%)
- Use os emojis dos blocos como marcadores visuais — só nos títulos, nunca dentro dos bullets

---

## Não faça

- **Não invente** números — use só os das skills anteriores e do plano de mídia
- **Não recomende mais de 1 ação** na PARTE 3, bloco 4
- **Não escreva** em texto corrido — sempre em bullets nas partes 3 e 4
- **Não use linguagem técnica desnecessária** — o CMO precisa entender em 30 segundos
- **Não compare** com semanas anteriores se não tiver dado histórico — apenas com as metas

---

## Tratamento de erros

- **Tabelas das skills anteriores não estão no contexto:** peça para o usuário rodar `consolidar-midia-lumina` e `extrair-receita-crm-lumina` antes
- **Plano de mídia faltando:** prossiga, mas avise que o status semáforo está sem referência de meta (use placeholders 🟦 "sem meta carregada")
- **ROAS real negativo ou impossível:** sinalize na tabela e investigue antes de prosseguir

---

## Exemplo de comportamento esperado

**Input:**
> "Agora calcule o ROAS real cruzando o gasto pixel da consolidação com a receita CRM."

**Output:**

1. ✅ Plano de mídia Lumina carregado com metas semanais derivadas.
2. PARTE 1 — Tabela reconciliation completa
3. PARTE 2 — Tabela semáforo vs metas (com mensagens "META BATIDA EM X%" / "DENTRO DA META" / "ABAIXO DA META EM X%")
4. PARTE 3 — Comentário executivo em 4 blocos com bullets
5. PARTE 4 — 3 bullets para Slack
6. Mensagem final: *"Reconciliation pronto. Próximo passo: rodar a skill `gerar-painel-resultados-midia-lumina` para produzir o painel HTML semanal."*
