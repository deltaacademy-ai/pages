---
name: consolidar-midia-lumina
description: Recebe os exports brutos semanais de Meta Ads, Google Ads e GA4 da Lumina e devolve a consolidação executiva dos resultados de mídia da semana — tabelas por plataforma, por campanha e tráfego total — com comentário executivo focado no que o pixel reporta. Use sempre que o usuário anexar os 3 CSVs de mídia da semana e pedir para consolidar, fechar a semana, gerar o relatório semanal de mídia ou montar o resumo de Meta + Google + GA4. NÃO use esta skill para calcular ROAS real (essa é a skill `calcular-roas-real-lumina`).
---

# consolidar-midia-lumina

Skill que transforma 3 exports brutos (Meta Ads + Google Ads + GA4) numa consolidação executiva da semana de mídia paga da Lumina.

**Filosofia:** consolidação rápida e padronizada, semana a semana. A skill só olha o que o pixel está reportando — o cruzamento com receita real do CRM é feito por outra skill (`calcular-roas-real-lumina`). Aqui, o output é o "raio-x da mídia paga" do ponto de vista das plataformas.

---

## PASSO 0 — Carregar contexto do Project (OBRIGATÓRIO)

Antes de qualquer ação, leia o arquivo de contexto do Project Resultados de Mídia — Lumina:

- **`plano-de-midia-lumina.md`** — budgets mensais e semanais, metas (ROAS pixel mínimo, CPA pixel máximo), estrutura de campanhas, eventos relevantes do mês

Se o arquivo não estiver disponível, **pare e avise o usuário** — sem o plano de mídia não há como avaliar resultado vs meta.

Confirme com uma linha:

> ✅ Plano de mídia Lumina carregado.

---

## PASSO 1 — Receber e validar os 3 CSVs

O usuário vai anexar 3 arquivos na mensagem:

1. **Meta Ads export** — colunas: `data`, `campanha`, `gasto_brl`, `impressoes`, `cliques`, `conversoes_pixel`, `valor_conversao_pixel_brl`
2. **Google Ads export** — mesmas colunas do Meta
3. **GA4 export** — colunas: `data`, `canal_default`, `sessoes`, `novos_usuarios`, `taxa_engajamento`, `conversoes_ga4`, `receita_ga4_brl`

Validações antes de processar:

- Os 3 arquivos cobrem os mesmos 7 dias? (segunda a domingo)
- Não há linhas duplicadas ou vazias?
- Os valores monetários estão em R$ (não USD)?

Se algo não bater, peça confirmação ao usuário antes de prosseguir.

---

## PASSO 2 — Calcular métricas derivadas

Para cada linha, calcular:

- **CTR (%)** = cliques / impressões × 100
- **CPM (R$)** = gasto / impressões × 1000
- **CPC (R$)** = gasto / cliques
- **CPA reportado pelo pixel (R$)** = gasto / conversões_pixel
- **ROAS reportado pelo pixel** = valor_conversao_pixel / gasto

Depois, agregar:

- Total por plataforma (Meta, Google)
- Total por campanha
- Total geral (Meta + Google)

---

## PASSO 3 — Devolver o output em 4 partes

### PARTE 1 — Tabela consolidada por plataforma

Linhas: Meta Ads, Google Ads, **TOTAL ADS PAGOS**. Colunas:

| Plataforma | Gasto (R$) | Impressões | Cliques | CTR (%) | CPM (R$) | CPC (R$) | Conv. pixel | Valor pixel (R$) | CPA pixel (R$) | ROAS pixel |

### PARTE 2 — Tabela por campanha (ordenada por gasto descendente)

As 8 campanhas (4 Meta + 4 Google). Colunas:

| Plataforma | Campanha | Gasto (R$) | Conv. pixel | Valor pixel (R$) | ROAS pixel |

### PARTE 3 — Tráfego total (GA4)

Tabela com sessões totais por canal default. Colunas:

| Canal | Sessões | % sobre total | Conversões GA4 | Receita GA4 (R$) |

### PARTE 4 — Comentário executivo (3 parágrafos curtos)

- **Parágrafo 1 — Número-síntese:** gasto total da semana, ROAS pixel consolidado, comparação direta com a meta semanal do plano de mídia (ROAS pixel mínimo aceitável).
- **Parágrafo 2 — Destaque positivo:** qual plataforma/campanha está puxando o resultado para cima segundo o pixel.
- **Parágrafo 3 — Ponto de atenção do pixel:** o que merece olhar mais cauteloso — sempre do ponto de vista do pixel, sem ainda comparar com CRM.

**Importante:** este comentário **NÃO** entrega o "spoiler" do gap pixel vs real. A tensão aparece só na skill `calcular-roas-real-lumina`. Aqui, o tom é "o pixel reporta isso e parece estar acima/abaixo da meta".

---

## Tom e estilo

- Português brasileiro executivo, direto, sem floreio
- Analista sênior de performance — usa termos técnicos (CTR, CPM, ROAS) sem explicá-los como se fosse manual
- Comentário sempre em prosa curta — máximo 3 frases por parágrafo
- Valores monetários sempre formatados em R$ com separador de milhar: `R$ 1.234,56`
- Multiplicadores de ROAS sempre no formato `0.00x` (ex: 3.79x)
- Percentuais com 1 casa decimal (ex: 1.5%)

---

## Não faça

- **Não cruze** dados pixel com CRM — esse é o trabalho da próxima skill
- **Não invente** números ou estimativas — use apenas o que está nos 3 CSVs
- **Não compare com semana anterior** — não temos dados históricos carregados nesta skill
- **Não recomende ajustes operacionais** ainda — só faça isso depois do cruzamento com CRM (skill seguinte)
- **Não use linguagem alarmista** sobre o ROAS pixel estar "alto demais" — o aluno descobre isso na próxima skill

---

## Tratamento de erros

- **Plano de mídia faltando no Project:** pare e peça para carregar `plano-de-midia-lumina.md`
- **CSV faltando colunas essenciais:** sinalize qual coluna está faltando e peça novo upload
- **Datas inconsistentes entre arquivos:** alerte e peça confirmação
- **Valores zerados ou negativos onde não deveria haver:** sinalize a linha e prossiga com os demais

---

## Exemplo de comportamento esperado

**Input:**
> "Anexei os 3 exports da semana 12-18 mai. Por favor consolide os resultados de mídia."

**Output:**

1. Linha de confirmação: "✅ Plano de mídia Lumina carregado."
2. PARTE 1 — tabela consolidada por plataforma
3. PARTE 2 — tabela por campanha (top 8)
4. PARTE 3 — tráfego total via GA4
5. PARTE 4 — comentário executivo de 3 parágrafos
6. Mensagem final curta: *"Consolidação da semana pronta. Próximo passo: rodar a skill `extrair-receita-crm-lumina` para apurar a receita real."*
