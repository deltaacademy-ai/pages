---
name: montar-post-lumina
description: "Recebe a copy completa de um carrossel da Lumina e gera artefato HTML autocontido que renderiza cada slide do carrossel no formato quadrado 1080x1080 do Instagram, aplicando rigorosamente a identidade visual Lumina (paleta wellness premium, tipografia Fraunces + Inter, espaço negativo). Use sempre que o usuário pedir para montar visualmente o carrossel a partir de uma copy pronta. Triggers: 'monta o carrossel', 'gera o post visual', 'transforma essa copy em arte', 'renderiza o carrossel', 'monta a peça final do Instagram'. Devolve um único arquivo HTML com 6 slides + bloco de legenda Instagram."
---

# montar-post-lumina

## Quando usar esta Skill

Use esta Skill sempre que o usuário pedir para montar visualmente o carrossel de Instagram da Lumina a partir de uma copy pronta (output da Skill `escrever-copy-lumina`). Triggers típicos: "monta o carrossel", "gera o post visual", "transforma essa copy em arte", "monta a peça final do Instagram", "renderiza o carrossel".

## O que esta Skill faz

Esta Skill recebe a copy completa de um carrossel da Lumina (capa + slides + tradução + CTA) e gera um **artefato HTML autocontido** que renderiza cada slide do carrossel no formato quadrado 1080×1080 (formato Instagram), aplicando rigorosamente a identidade visual Lumina — paleta wellness premium, tipografia Fraunces + Inter, espaço negativo, hierarquia visual serena.

O artefato HTML simula como o carrossel apareceria publicado no Instagram. O usuário pode visualizar diretamente no Claude, baixar como arquivo `.html` e abrir no navegador.

## Inputs que a Skill espera

A Skill espera **um input do usuário** no momento da invocação:

1. **Copy completa do carrossel** — bloco de texto com capa + slides numerados + tradução + CTA + legenda + hashtags. Deve ser o output direto da Skill `escrever-copy-lumina`.

Se a copy estiver incompleta (faltando slides ou CTA), a Skill pergunta antes de gerar. Não inventa conteúdo.

## Estrutura do artefato HTML gerado

O artefato HTML que a Skill produz tem a seguinte estrutura:

### Container principal

Página HTML responsiva com fundo neutro (branco quente Lumina `#FBF9F5`). Os slides aparecem dispostos em grid vertical para visualização contínua — cada slide ocupando 1080×1080 com margem entre eles.

### Cada slide do carrossel

Cada slide é renderizado como uma `<div>` quadrada 1080×1080 (com `aspect-ratio: 1/1` para responsividade) contendo:

- **Fundo do slide** — alternância entre branco quente (`#FBF9F5`) e areia (`#E8DFC9`) para criar ritmo visual no scroll, com paleta secundária aparecendo em detalhes (verde-musgo, coral terroso).

- **Numeração discreta** — número do slide ("01/06", "02/06" etc.) no canto superior direito em Inter pequeno (cinza-taupe `#8A857D`).

- **Logo Lumina** — pequeno círculo verde-musgo vazado + palavra "lumina" em Fraunces lowercase no canto inferior esquerdo. Aparece em todos os slides exceto a capa, onde aparece levemente maior.

- **Conteúdo principal** — título e corpo do slide centralizados verticalmente, com muito espaço negativo:
  - Títulos em **Fraunces** (peso 600), tamanho grande, sem caixa alta exagerada.
  - Corpo do texto em **Inter** (peso 400 ou 500), tamanho médio, line-height generoso (1.6 ou 1.7).
  - Hierarquia visual feita por **espaçamento**, não por bordas ou caixas.

- **Detalhes gráficos sutis** — linha fina decorativa em verde-musgo separando título e corpo em alguns slides. Sem ornamento pesado, sem sombras agressivas, sem gradientes berrantes.

### Slide de capa (Slide 01)

Construído com mais destaque visual:
- Headline em Fraunces grande (tipo 64-72px) ocupando 60% do slide.
- Frase de promessa em Inter abaixo, menor, em cinza-taupe.
- Logo Lumina maior e centralizado abaixo.
- Pode incluir um pequeno elemento visual decorativo no canto (formato gummy estilizado em SVG, em verde-musgo ou coral).

### Slides de desenvolvimento (02 a 04)

Estrutura padrão:
- Tag pequena no topo indicando o número do mito ("MITO 01", "MITO 02" etc.) em Inter caixa alta tracking expandido, na cor coral terroso.
- Título do mito em Fraunces grande, entre aspas se for transcrição literal.
- Corpo explicativo em Inter abaixo, com a parte "Na prática:" destacada em verde-musgo.

### Slide de tradução (05)

Estrutura padrão:
- Título "O que muda quando você sabe disso" em Fraunces.
- 2-3 parágrafos curtos em Inter, com palavra-chave (Mariana, suplementação séria) em verde-musgo.

### Slide de CTA (06)

Estrutura padrão:
- Texto principal de CTA em Fraunces, mais íntimo e menor que os títulos anteriores.
- 1 linha de instrução em Inter (Salvar / Compartilhar / Link na bio).
- Logo Lumina centralizado em destaque.
- Mais espaço negativo que os outros slides para "respirar" no encerramento.

### Bloco de legenda (fora dos slides)

Abaixo do grid dos 6 slides, a Skill inclui um bloco visual extra simulando como a legenda apareceria abaixo do post no Instagram:
- Caixa cinza muito claro (`#F5F2EC`) com cantos arredondados suaves.
- Avatar circular pequeno simulando perfil "@lumina" no topo.
- Texto da legenda em Inter com line-height confortável.
- Hashtags em coral terroso ao final.

## Regras visuais inegociáveis

1. **Paleta Lumina rigorosa.** Use APENAS as cores oficiais:
   - Branco quente: `#FBF9F5` (fundo principal)
   - Verde-musgo: `#5C7A5A` (cor de marca, destaques)
   - Coral terroso: `#C97A5A` (CTAs, tags, detalhes)
   - Cinza-taupe: `#8A857D` (textos secundários)
   - Verde-claro pálido: `#D4DDC9` (fundos secundários sutis)
   - Areia: `#E8DFC9` (fundo alternativo)

   NUNCA use: preto puro (#000), cores saturadas (vermelho, azul royal, amarelo neon), cores fluorescentes.

2. **Tipografia obrigatória.** Import das duas fontes via Google Fonts no `<head>`:
   ```
   @import url('https://fonts.googleapis.com/css2?family=Fraunces:wght@400;500;600;700&family=Inter:wght@400;500;600&display=swap');
   ```
   - Fraunces — usar em títulos, headlines, citações.
   - Inter — usar em corpo de texto, tags, legendas, números.
   - Não usar outras fontes.

3. **Muito espaço negativo.** Cada slide deve ter padding interno mínimo de 80px. Nada cola na borda. Wellness premium respira.

4. **Sem ornamento pesado.** Linhas finas (1-2px) em verde-musgo são permitidas como divisores discretos. Sombras grandes, gradientes berrantes, bordas grossas — proibidos.

5. **Hierarquia por espaçamento e tamanho.** Não usar caixas, balões ou containers chamativos. A hierarquia visual vem do tamanho da fonte e do espaço entre elementos.

6. **Mobile-friendly.** Os slides devem ser visualizáveis em qualquer tela. Usar `aspect-ratio: 1/1` em vez de altura fixa.

## Estrutura técnica do HTML

A Skill gera um único arquivo HTML autocontido com:

- **`<head>`** com `<meta>` charset/viewport, título, import do Google Fonts e CSS interno (`<style>`).
- **CSS** organizado em variáveis customizadas para as cores Lumina (`--lumina-cream`, `--lumina-green`, `--lumina-coral`, etc.) e classes utilitárias por elemento (`.slide`, `.title`, `.tag-mito`, `.cta`, etc.).
- **`<body>`** com container principal de fundo branco quente, grid vertical dos 6 slides + bloco de legenda.
- **JavaScript mínimo** (apenas se necessário) — nenhuma dependência externa, nenhum framework. HTML + CSS puro.

## Output enxuto

A Skill entrega **apenas o artefato HTML** — sem preâmbulo explicando o que vai fazer, sem comentários sobre escolhas de design, sem perguntas adicionais (a menos que a copy de input esteja incompleta).

## Conexão com outras Skills do Project

O artefato HTML gerado é o **post finalizado** da Bruna. Ela pode:
- Visualizar diretamente no Claude.
- Baixar como `.html` e abrir no navegador para validação final.
- Tirar screenshot de cada slide e subir como imagem no Instagram.
- Em produção real (fora desta aula), o output serve como mockup para passar ao designer ou ferramenta de design profissional.
