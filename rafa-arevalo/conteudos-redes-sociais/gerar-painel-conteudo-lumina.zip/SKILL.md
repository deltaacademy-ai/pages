---
name: gerar-painel-conteudo-lumina
description: "Gera um painel HTML autocontido de análise de performance do Instagram da Lumina a partir de dados de publicações (CSV ou tabela). Use sempre que o usuário pedir para analisar o desempenho do Instagram da Lumina, gerar dashboard de performance, montar relatório do mês de conteúdo, ou consolidar os números de posts publicados. Triggers: 'analisa a performance do mês', 'monta o painel de conteúdo', 'gera o dashboard do Instagram', 'fecha o relatório mensal', 'como performaram os posts'. O painel inclui 7 indicadores obrigatórios: crescimento de seguidores, alcance e visualizações, interações, taxa de engajamento, conteúdo top performer, cliques na bio e leads captados — aplicando identidade visual Lumina (paleta wellness premium, Fraunces + Inter)."
---

# gerar-painel-conteudo-lumina

## Quando usar esta Skill

Use esta Skill sempre que o usuário pedir para gerar o painel de análise de performance dos posts do Instagram da Lumina, fechar relatório mensal, consolidar números do mês, ou analisar como performaram as publicações. Triggers típicos: "analisa a performance do mês", "monta o painel de conteúdo", "gera o dashboard do Instagram", "fecha o relatório mensal", "como performaram os posts".

## O que esta Skill faz

Esta Skill recebe dados de performance de publicações do Instagram da Lumina (em formato CSV anexado ao chat ou tabela colada no prompt) e gera um **artefato HTML autocontido** com o painel de análise completo do período. O painel é editorial, sereno, no padrão visual Lumina — pronto para a Bruna apresentar à liderança da marca ou tomar decisões editoriais para o próximo ciclo.

## Inputs que a Skill espera

A Skill espera **um input do usuário** no momento da invocação:

1. **Dados de performance** — arquivo CSV anexado ao chat ou tabela colada no prompt. Os dados devem incluir, por post:
   - Data de publicação
   - Tipo de post (Carrossel, Insight, Framework, Reels, etc.)
   - Título/headline do post
   - Linha editorial
   - Estágio do funil (NOTAM VOCÊ, LEMBRAM DE VOCÊ, etc.)
   - Alcance, impressões, visualizações de vídeo (quando aplicável)
   - Curtidas, comentários, salvamentos, compartilhamentos
   - Cliques no link da bio
   - Leads captados

   E, separadamente, o **resumo da conta no período**: seguidores no início, seguidores no fim, ganhos, perdidos, crescimento líquido.

Se os dados estiverem incompletos (faltando alguma das métricas obrigatórias), a Skill pergunta antes de gerar. Não inventa dados.

## Os 7 indicadores obrigatórios do painel

O painel sempre inclui estas 7 seções de análise, na ordem:

### 1. Crescimento de seguidores

Bloco com:
- Saldo líquido do período (ex: "+762 novos seguidores")
- Total ganhos (892) e total perdidos (130) lado a lado
- Variação percentual em relação ao início do período (+6,1%)
- Pequeno gráfico simples (barra empilhada ou número grande em destaque)

### 2. Alcance e visualizações

Bloco com:
- Alcance total do período (soma de alcance de todos os posts)
- Impressões totais
- Alcance médio por post
- Post de maior alcance em destaque (título + número)

### 3. Interações totais

Bloco somando todas as interações do período:
- Curtidas totais
- Comentários totais
- Salvamentos totais
- Compartilhamentos totais
- Cada métrica com seu próprio card

### 4. Taxa de engajamento

Bloco com:
- Taxa de engajamento média do período — fórmula: `(curtidas + comentários + salvamentos + compartilhamentos) / alcance × 100`
- Comparação com benchmark do setor wellness (~3-5% considerado bom)
- Tendência ao longo do período (subiu, manteve, caiu)

### 5. Conteúdo que mais performou

Ranking dos **3 posts top do período** ordenados por engajamento absoluto (curtidas + comentários + salvamentos + compartilhamentos):
- Posição (1º, 2º, 3º)
- Título do post
- Linha editorial + estágio do funil
- Métricas-chave (alcance, engajamento total, taxa de engajamento)
- Análise curta de por que aquele post performou (1-2 frases)

### 6. Cliques no link da bio

Bloco com:
- Total de cliques no link da bio do período
- Posts que mais geraram clique (top 3, com título e número)
- Análise do que faz post gerar clique (1-2 frases)

### 7. Leads captados

Bloco com:
- Total de leads captados no período (via links traqueáveis)
- Conversão de cliques em leads (% de quem clicou virou lead)
- Posts que mais geraram lead (top 3, com título e número)

## Bloco final — Observações estratégicas

Depois das 7 seções, o painel inclui um bloco curto (4-6 bullets) com leitura estratégica:
- Qual linha editorial performou melhor no período
- Qual estágio do funil teve maior tração
- Padrão observado nos posts top
- Recomendação para o próximo ciclo

## Estrutura visual do painel

### Layout geral

- Painel em página única, scrollável.
- Header com logo Lumina, título "Performance do Instagram" e período analisado.
- Cards organizados em grid responsivo (3 colunas em desktop, 1 em mobile).
- Espaço negativo generoso entre seções.

### Paleta Lumina aplicada

- **Branco quente** (`#FBF9F5`) — fundo principal
- **Areia** (`#E8DFC9`) — fundo de cards
- **Verde-musgo** (`#5C7A5A`) — números principais, headers, ícones
- **Coral terroso** (`#C97A5A`) — destaques, métricas-chave, badges
- **Cinza-taupe** (`#8A857D`) — textos secundários, labels
- **Verde-claro pálido** (`#D4DDC9`) — fundos secundários e backgrounds de bar chart

### Tipografia

- **Fraunces** — números grandes, títulos de cards, headlines de seções
- **Inter** — corpo, labels, descrições

### Componentes visuais

- **Big numbers** — métricas principais aparecem em Fraunces grande (48-64px) em verde-musgo
- **Cards** — fundo areia ou branco quente alternando, cantos arredondados suaves (12px), sem sombras pesadas
- **Linha decorativa fina** — verde-musgo 1px separando seções
- **Mini badges** — para linhas editoriais e estágios do funil, em coral terroso
- **Listas de posts top** — formatação editorial limpa, com posição em coral, título em Fraunces e métricas em Inter
- **Sem gráficos complexos** — usar barras simples em CSS quando necessário (sem dependência de bibliotecas externas tipo Chart.js)

## Regras visuais inegociáveis

1. **Paleta Lumina rigorosa.** Use APENAS as 6 cores oficiais.
2. **Fraunces + Inter via Google Fonts** importadas no `<head>`.
3. **Sem sombras pesadas, gradientes berrantes, cores neon ou saturadas.**
4. **Hierarquia por tamanho e espaço**, nunca por caixas chamativas.
5. **Mobile-first** — o painel precisa ser legível em telas pequenas (responsive design via CSS Grid e Flexbox).
6. **Sem dependências externas** — HTML + CSS puro. Pode usar JavaScript mínimo se necessário, mas nada de bibliotecas pesadas.

## Estrutura técnica do HTML

O artefato gerado é um único arquivo HTML com:
- `<head>` com meta charset/viewport, título do painel, import do Google Fonts e CSS interno.
- CSS organizado em variáveis customizadas para as cores Lumina e classes utilitárias por componente (`.card`, `.big-number`, `.badge`, `.section-header`, etc.).
- `<body>` com header + 7 seções dos indicadores + bloco final de observações.

## Output enxuto

A Skill entrega **apenas o artefato HTML** — sem preâmbulo explicando o que vai fazer, sem listar as decisões de design, sem comentar sobre os dados antes de renderizar. Direto ao artefato.

## Conexão com o ciclo editorial

O painel gerado por esta Skill é o **fechamento do ciclo de produção de conteúdo da Lumina**:
- AP02 — Plano editorial gerado
- AP03 — Copy escrita
- AP04 — Post visual montado
- **AP05 — Painel de performance fechado**

Os insights do painel alimentam o próximo ciclo de planejamento (próxima invocação da Skill `planejar-mes-lumina`) — formando um loop completo de produção, publicação e análise.
